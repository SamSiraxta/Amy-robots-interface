﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Speech;
using Android.Speech.Tts;
using Android.Widget;
using Java.Util;
using System;
using AmyFace;
using Android.Content.PM;
using Android.Runtime;
using System.Collections.Generic;
using System.Threading;

namespace AmyProgram
{
    [Activity(Label = "AmyFace", MainLauncher = true, Theme = "@android:style/Theme.NoTitleBar", ScreenOrientation = ScreenOrientation.Landscape)]
    public class MainActivity : Activity, TextToSpeech.IOnInitListener, IRecognitionListener
    {
        // variables declaration
        private string response;
        private TextToSpeech textToSpeech;
        private Button recButton, buttonCommand, buttonList;
        private ImageView imageView;
        private Locale language;
        private Boolean speech;
        private readonly object locker = new object();
        // objects
        private RoboticMotion rbt = new RoboticMotion();
        private AmyProgram.Chat.Chat cht = new AmyProgram.Chat.Chat();
        private SpeechRecognizer voiceSpeech;

        protected override void OnCreate(Bundle savedInstanceState)
        {
            // set our view from the "main" layout resource
            base.OnCreate(savedInstanceState);
            SetContentView(Resource.Layout.Main);
            // get the resources from the layout
            recButton = FindViewById<Button>(Resource.Id.btnRecord);
            // set up the TextToSpeech object, third parameter is the speech engine to use
            textToSpeech = new TextToSpeech(this, this, "com.google.android.tts");
            // set up the speech to use the default langauge
            language = new Locale("es", "ES");
            textToSpeech.SetLanguage(language);
            // set the speed and pitch
            textToSpeech.SetPitch(.9f);
            textToSpeech.SetSpeechRate(.9f);
            // Eyes image
            imageView = FindViewById<ImageView>(Resource.Id.imagenCara);
            Android.Graphics.Drawables.AnimationDrawable animation = (Android.Graphics.Drawables.AnimationDrawable)imageView.Drawable;
            animation.Start();
            // set the music src
            buttonCommand = FindViewById<Button>(Resource.Id.addCommand);
            buttonList = FindViewById<Button>(Resource.Id.list);

            // start logic statements off
            this.Run();
        }

        public void Run()
        {
            buttonList.Click += EditCommand;
            recButton.Click += VoiceOnParallel;
        }

        public void SpeechMicro()
        { 
            lock (locker)
            {
                if (speech)
                {
                    voiceSpeech = SpeechRecognizer.CreateSpeechRecognizer(this);
                    voiceSpeech.SetRecognitionListener(this);
                    Intent voiceIntent = new Intent(RecognizerIntent.ActionRecognizeSpeech);
                    voiceIntent.PutExtra(RecognizerIntent.ExtraLanguageModel, RecognizerIntent.LanguageModelFreeForm);
                    voiceIntent.PutExtra(RecognizerIntent.ExtraLanguage, Java.Util.Locale.Default);
                    voiceSpeech.StartListening(voiceIntent);
                }
            }
        }

        public double EstimateTemp(string stringResp)
        {
            // speech rate is aproximately 10.156 letters by second
            return ((stringResp.Length / 10.156) * 1000);
        }

        public void EditCommand(object sender, EventArgs e)
        {
            Intent editList = new Intent(this, typeof(ListEdit));
            StartActivity(editList);
        }

        // interface method required for IOnInitListener
        void TextToSpeech.IOnInitListener.OnInit(OperationResult status)
        {
            // if we get an error, default to the default language
            if (status == OperationResult.Error) { textToSpeech.SetLanguage(Java.Util.Locale.Default); }
            // if the listener is ok, set the lang
            if (status == OperationResult.Success) { textToSpeech.SetLanguage(language); }
        }

        // create the intent and start a listener
        public void VoiceOnParallel(object sender, EventArgs Args) { speech = true; SpeechMicro(); }

        public void OnResults(Bundle results)
        {
            IList<string> matches = results.GetStringArrayList(SpeechRecognizer.ResultsRecognition);
            Android.Util.Log.WriteLine(Android.Util.LogPriority.Debug, "Command", "Command Heard: " + matches[0]);
            Toast.MakeText(this, matches[0], ToastLength.Short).Show();
            // send ASCII command to get motion response
            rbt.GetCommand(matches[0]);
            // speaking
            cht.GetChat(matches[0]);
            response = cht.ReturnCommand();

            if (!string.IsNullOrEmpty(response))
            {
                textToSpeech.Speak(response, QueueMode.Flush, null);
                Thread.Sleep(Convert.ToInt32(EstimateTemp(response)));
                if (response == "hasta luego") { speech = false; }
                cht.Reset();
                SpeechMicro();
            }
            if (matches[0].Contains("busca"))
            {
                matches[0] = matches[0].Replace("busca", "");
                textToSpeech.Speak("buscando", QueueMode.Flush, null);
                Thread.Sleep(Convert.ToInt32(EstimateTemp(response)));
                var uri = Android.Net.Uri.Parse("https://www.google.com/search?q=" + matches[0]);
                Intent intWeb = new Intent(Intent.ActionView, uri);
                StartActivity(intWeb);
            }
        }

        public void OnBeginningOfSpeech() { }
        public void OnBufferReceived(byte[] buffer) { }
        public void OnEndOfSpeech() { }
        public void OnError([GeneratedEnum] SpeechRecognizerError error) { }
        public void OnEvent(int eventType, Bundle @params) { }
        public void OnPartialResults(Bundle partialResults) { }
        public void OnReadyForSpeech(Bundle @params) { }
        public void OnRmsChanged(float rmsdB) { }
    }
}