﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Widget;
using System;
using AmyFace;
using System.Collections.Generic;
using AmyProgram.Chat;

namespace AmyProgram
{
    [Activity(Label = "")]
    public class ListEdit : Activity
    {
        private EditText comandText, responseText;
        private Button buttonCommand, goBack;
        private SqlCommand sqlcomnd = new SqlCommand();
        private ListView listnames;
        private List<string> itemList;
        private ArrayAdapter<string> myAdapter;
        private int indexPosition;

        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);
            SetContentView(Resource.Layout.listView);

            // edittext for name, id and command
            comandText = FindViewById<EditText>(Resource.Id.comando);
            responseText = FindViewById<EditText>(Resource.Id.respuesta);
            buttonCommand = FindViewById<Button>(Resource.Id.addCommand);
            buttonCommand.Click += OnAddCommand;

            goBack = FindViewById<Button>(Resource.Id.volver);
            goBack.Click += GoHome;

            // array of items
            listnames = FindViewById<ListView>(Resource.Id.listView1);
            listnames.ItemClick += ListNamesClick;
            itemList = new List<string>();

            // trigger called when a row's clicked, so it gets back the position
            listnames.ItemClick += lv_ItemClick; void lv_ItemClick(object sender, AdapterView.ItemClickEventArgs e)
            {
                indexPosition = e.Position;
            }

            // create Table
            // make a listview with table values from itemList
            myAdapter = new ArrayAdapter<string>(this, Android.Resource.Layout.SimpleListItem1, itemList);
            listnames.Adapter = myAdapter;
            this.UpdateTable();
        }

        // calculate item related to the index of listview which was selected
        public int CalcItem()
        {
            int cont = 0;
            int itemCalc = 0;
            var table = sqlcomnd.GetTable();
            foreach (var item in table)
            {
                if (cont == indexPosition)
                {
                    itemCalc = item.ID;
                }
                cont++;
            }
            return itemCalc;
        }

        // send commands to data base
        public void OnAddCommand(object sender, EventArgs e)
        {
            // setting items on SQL database
            sqlcomnd.SetItem(comandText.Text, responseText.Text);

            // Clean edittexts
            comandText.Text = "";
            responseText.Text = "";

            // Update listview
            myAdapter.Clear();
            this.UpdateTable();
        }

        //update table if new change is made
        public void UpdateTable()
        {
            // get Table from SQL
            itemList.Clear();
            var table = sqlcomnd.GetTable();

            int cont = 0;
            foreach (var item in table)
            {
                string a = item.Command.ToString();
                itemList.Add(item.ID + " : " + " " + "COMANDO: " + item.Command + " " + "RESPUESTA: " + item.Response);

                Android.Util.Log.WriteLine(Android.Util.LogPriority.Debug, "itemList", "ITEMLIST: " + itemList[cont]);
                myAdapter.Add(itemList[cont]);
                cont++;
            }
        }

        public void ListNamesClick(object sender, EventArgs e)
        {
            var dlgAlert = (new AlertDialog.Builder(this)).Create();
            dlgAlert.SetMessage("Eliminar este comando de texto?");
            dlgAlert.SetButton("Eliminar", DeleteButton);
            dlgAlert.SetButton2("Cancelar", CancelButton);
            dlgAlert.Show();
        }

        public void DeleteButton(object sender, DialogClickEventArgs e)
        {
            // delete selected item from ListEdit 
            myAdapter.Clear();
            itemList.RemoveAt(indexPosition);

            // delete selected item from SQL database
            var table = sqlcomnd.GetTable();
            int itemCalc = this.CalcItem();
            foreach (var item in table)
            {
                if (item.ID == itemCalc)
                {
                    sqlcomnd.DeleteItem(item);
                }
            }

            this.UpdateTable();

            AlertDialog objAlertDialog = sender as AlertDialog;
            Button btnClicked = objAlertDialog.GetButton(e.Which);
            Toast.MakeText(this, "Elemento eliminado", ToastLength.Short).Show();
        }

        public void CancelButton(object sender, DialogClickEventArgs e)
        {
            AlertDialog objAlertDialog = sender as AlertDialog;
            Button btnClicked = objAlertDialog.GetButton(e.Which);
            Toast.MakeText(this, "Operación cancelada", ToastLength.Short).Show();
        }

        // go home
        public void GoHome(object sender, EventArgs e)
        {
            Intent gohome = new Intent(this, typeof(MainActivity));
            StartActivity(gohome);
        }
    }
}