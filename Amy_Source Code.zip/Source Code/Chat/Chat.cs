﻿namespace AmyProgram.Chat
{
    public class Chat
    {
        public string response = "";
        public SqlCommand sqlcomnd = new SqlCommand();
       
        public void GetChat(string command)
        {
            // robotic motion commands
            if (command.Contains("no camines") || command.Contains("detente") || command.Contains("quieta") || command.Contains("quieto") == true) response = "vale";
            if (command.Contains("atrás") || command.Contains("retrocede") == true) response = "retrocediendo";
            if (command.Contains("izquierda") == true) response = "girando hacia la izquierda";
            if (command.Contains("derecha") == true) response = "girando hacia la derecha";
            if (command.Contains("ven") == true) response = "te sigo";
            if (command.Contains("avanza") || command.Contains("adelante")) response = "vooy";
            if (command.Contains("círculo") == true) response = "girando";
            // chat voice commands
            if (command.Contains("hola") == true) response = "hola, cómo estás?";
            if (command.Contains("adiós") == true) response = "hasta luego";
            if (command.Contains("qué tal") || command.Contains("cómo andamos") == true) response = "muy bien, y tú?";
            if (command.Contains("quién eres") || command.Contains("cómo te llamas") == true) response = "Soy AID BOT, un proyecto de ledisson a i t";
            if (command.Contains("para") || command.Contains("párate") || command.Contains("stop") == true) response = "vale, ya paro";
            if (command.Contains("cuéntame un chiste") == true) response = "esto eran dos magdalenas en una nevera y dice una. ai qué frío hace. y dice la otra. AAA! una magdalena que habla";
            if (command.Contains("cuéntame algo") == true) response = "qué opinas del color que le da el pulpo a las patatas?";
            if (command.Contains("dime algo") == true) response = "Clavelitos, clavelitos, Clavelitos de mi corazón. Hoy te traigo clavelitos Colorados igual que un fresón. Si algún día clavelitos No lograra poderte traer,No te creas que ya no te quiero, Es que no te los pude traer. ";
            if (command.Contains("*") == true) response = "por favor, no digas improperios";
            if (command.Contains("qué haces") == true) response = "hablar contigo";
            if (command.Contains("buenos días") || command.Contains("buenas tardes") || command.Contains("buenas noches") == true) response = "buenos días a ti también";
            if (command.Contains("soy") == true) response = "Encantada de conocerte, un placer";
            if (command.Contains("cuál es tu función") == true) response = "Ayudar a la gente";

            if (string.IsNullOrEmpty(response))
            {
                // if command is not a keyword, it calls the SQL database 
                // to check out if a word is learnt despite those hotwords 
                response = sqlcomnd.GetItem(command);
            }
        }

        public string ReturnCommand() { return response; }
        public void Reset() { response = ""; }
    }
}