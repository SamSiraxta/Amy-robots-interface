﻿using AmyProgram.SQL;
using SQLite;
using System;

namespace AmyProgram.Chat
{
    public class SqlCommand
    {
        public RegEntity regCommd = new RegEntity();
        public Sqldata sql = new Sqldata();
        public string response = "";

        public void SetItem(String comando, String respuesta)
        {
            try
            {
                //catch strings up to save them into the DataBase
                regCommd.Command = comando;
                regCommd.Response = respuesta;
                sql.SaveItem(regCommd);
            }
            catch (Exception e)
            {
                Console.WriteLine(e); //Show the exception code
                Android.Util.Log.WriteLine(Android.Util.LogPriority.Debug, "SetError", "SQL ERROR: ITEM NOT SET");
            }
        }

        public string GetItem(string command)
        {
            string resp = "";
            try
            {
                regCommd = sql.GetItem(command);
                resp = regCommd.Response;
            }
            catch (Exception e)
            {
                Console.WriteLine(e); //Show the exception code
                Android.Util.Log.WriteLine(Android.Util.LogPriority.Debug, "GetError", "SQL ERROR: ITEM NOT FOUND");
            }
            return resp;
        }

        public TableQuery<RegEntity> GetTable()
        {
            TableQuery<RegEntity> table = null;
            try { table = sql.GetTable(); }
            catch (Exception e)
            {
                Console.WriteLine(e); //Show the exception code
                Android.Util.Log.WriteLine(Android.Util.LogPriority.Debug, "GetError", "SQL ERROR: TABLE NOT MADE");
            }
            return table;
        }

        public void DeleteItem(RegEntity item)
        {
            try { sql.DeleteItem(item); }
            catch (Exception e)
            {
                Console.WriteLine(e); //Show the exception code
                Android.Util.Log.WriteLine(Android.Util.LogPriority.Debug, "GetError", "SQL ERROR: ITEM NOT DELETED");
            }
        }
    }
}