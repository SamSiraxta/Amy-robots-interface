﻿using SQLite;
namespace AmyProgram.SQL
{
    public class RegEntity
    {
        public RegEntity() { }

        [PrimaryKey, AutoIncrement]
        public int ID { get; set; }

        public string Command { get; set; }
        public string Response { get; set; }
    }
}