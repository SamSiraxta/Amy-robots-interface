﻿using SQLite;
using PCLStorage;

namespace AmyProgram.SQL
{
    public class Sqldata
    {
        static readonly object locker = new object();
        SQLiteConnection database;

        public Sqldata()
        {
            // create the table
            database = GetConnection();
            database.CreateTable<RegEntity>();
        }

        public SQLite.SQLiteConnection GetConnection()
        {
            SQLiteConnection sqlitConnection;
            var sqliteFilename = "SQLiteDataBase.db3";
            IFolder folder = FileSystem.Current.LocalStorage;
            string path = PortablePath.Combine(folder.Path.ToString(), sqliteFilename);
            sqlitConnection = new SQLite.SQLiteConnection(path);
            return sqlitConnection;
        }

        public TableQuery<RegEntity> GetTable() { lock (locker) { return database.Table<RegEntity>(); } }
        public RegEntity GetItem(string command) { lock (locker) { return database.Table<RegEntity>().FirstOrDefault(x => x.Command == command); } }
        public int SaveItem(RegEntity item) { lock (locker) { return database.Insert(item); } }
        public int DeleteItem(RegEntity item) { lock (locker) { return database.Delete(item); } }
    }
}