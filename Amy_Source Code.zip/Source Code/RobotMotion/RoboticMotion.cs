﻿using Android.App;

namespace AmyProgram
{
    [Activity(Label = "AmyProgram", MainLauncher = true)]
    public class RoboticMotion
    {
        public void GetCommand(string command)
        {
            if (command.Contains("no camines") == true) { LowerMachineConnect.SendCmd("#VL0A0"); }
            if (command.Contains("atrás") || command.Contains("retrocede") == true) { LowerMachineConnect.SendCmd("#VL-2A0"); }
            if (command.Contains("izquierda") == true) { LowerMachineConnect.SendCmd("#VL0A2"); }
            if (command.Contains("derecha") == true) { LowerMachineConnect.SendCmd("#VL0A-2"); }
            if (command.Contains("ven") == true) { LowerMachineConnect.SendCmd("#FOLLO"); }
            if (command.Contains("baila") == true) { LowerMachineConnect.SendCmd("#DANCE"); }
            if (command.Contains("gira") == true) { LowerMachineConnect.SendCmd("#TURND" + 90); }
            if (command.Contains("avanza") || command.Contains("delante")) { LowerMachineConnect.SendCmd("#SL2A0"); }
            if (command.Contains("círculo") == true) { LowerMachineConnect.SendCmd("#SL2A2"); }
            if (command.Contains("para") || command.Contains("párate") == true) { LowerMachineConnect.SendCmd("#STFO"); }
        }
    }
}