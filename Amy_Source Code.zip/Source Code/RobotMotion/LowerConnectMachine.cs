﻿using Android.App;
using System;
using System.Net.Sockets;

namespace AmyProgram
{
    [Activity(Label = "AmyProgram", MainLauncher = true)]
    public class LowerMachineConnect
    {
        public static String HOST = "10.42.0.1";
        public static int port = 12306;

        public static void SendCmd(String msg)
        {
            Android.Util.Log.WriteLine(Android.Util.LogPriority.Debug, "SendCmd", "Command to Send: " + msg);
            Send(HOST, msg); // send ASCII command
        }

        static void Send(String server, String message)
        {
            // create a TcpClient.
            TcpClient client = new TcpClient(server, port);

            // translate the passed message into ASCII and store it as a Byte array
            Byte[] data = System.Text.Encoding.ASCII.GetBytes(message);
            NetworkStream stream = client.GetStream();

            // send the message to the connected TcpServer
            stream.Write(data, 0, data.Length);

            // close everything
            stream.Close();
            client.Close();
        }
    }
}